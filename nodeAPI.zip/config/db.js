module.exports={
    //database:'mongodb://localhost:27017/myUrideDB',
    //secert:'secret',
    otp_length:6,
    otp_config:{
        digits:true,
        upperCaseAlphabets:false,
        specialChars:false,
        //String:false,
        Alphabets:false,
        lowerCaseAlphabets:false
        
    }
}